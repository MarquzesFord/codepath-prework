package com.example.helloworld

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView


// THis Kotlin file is where we're going to be handling user interaction
class MainActivity : AppCompatActivity() {
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show this layout file: activity.main
        setContentView(R.layout.activity_main)

        // User can tap a button to change the text color of the label.
        // 1. Add a button to our layout

        //Get a reference to button
        // 2. Set up logic to know when user has tapped on button.
        findViewById<Button>(R.id.button).setOnClickListener {
            // Handles Button tap
            // 2. Change the color of text
            Log.i("Marquzes", "Tapped on button")
            // 1. Get a reference to the text view
            // 2. Set color to text view
            findViewById<TextView>(R.id.textView).setTextColor(R.color.purple)

        }
    }
}